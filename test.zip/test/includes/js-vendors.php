<!-- Vendors -->
<script src="<?php echo $root; ?>assets/vendor/plugins/plugins.js"></script>
<script src="<?php echo $root; ?>assets/vendor/designesia/designesia.js"></script>
<script src="<?php echo $root; ?>assets/vendor/swiper/swiper.js"></script>
<!-- Custom Scripts -->
<script src="<?php echo $root; ?>assets/js/custom.js"></script>