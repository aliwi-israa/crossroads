	<!-- Stylesheets -->
	<link href="<?php echo $root; ?>assets/vendor/plugins/plugins.css" rel="stylesheet">
	<link href="<?php echo $root; ?>assets/vendor/bootstrap/bootstrap.min.css" rel="stylesheet">
	<link href="<?php echo $root; ?>assets/vendor/swiper/swiper.css" rel="stylesheet">
	<link href="<?php echo $root; ?>assets/css/style.css" rel="stylesheet">
	<!--Favicon-->
	<link rel="icon" href="<?php echo $root; ?>assets/images/icon.png" type="image/x-icon">